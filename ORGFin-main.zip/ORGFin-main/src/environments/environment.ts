// Antonio Batista - Organizador de gastos - 2024-07-25
// Arquivo para armazenar as variáveis de ambiente, como as chaves do Supabase.

export const environment = {
  production: false,
  supabaseUrl: 'https://qdfwriaoqfqndwpkitzp.supabase.co',
  supabaseAnonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFkZndyaWFvcWZxbmR3cGtpdHpwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ0Mjg5MTIsImV4cCI6MjA4MDAwNDkxMn0.BUX87snn1ZpH1t7EqSu-0WO-m7iU5SP_jpa5VCf1SkA',
};
